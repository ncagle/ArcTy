﻿using System;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Editor;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geometry;


namespace BridgeTunnelFord_Builder_Prime
{
    public class Ford : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public Ford()
        {
        }

        protected override void OnClick()
        {
            IApplication m_application = ArcMap.Application;
            UID editorUid = new UID();
            editorUid.Value = "esriEditor.Editor";
            IMxDocument pMxdoc = (IMxDocument)ArcMap.Application.Document;
            IEditor3 editor = m_application.FindExtensionByCLSID(editorUid) as IEditor3;
            IWorkspace workspace = null;

            //Stops program unless an editing session is active; sets workspace to editing session otherwise
            if (editor.EditState == esriEditState.esriStateEditing)
            {
                workspace = editor.EditWorkspace;
            }
            else
            {
                MessageBox.Show("Editing session required");
                return;
            }

            IFeatureWorkspace workspacef = workspace as IFeatureWorkspace;

            IActiveView activeView = ArcMap.Document.ActiveView;
            IMap pMap = activeView.FocusMap;
            ISelection selection = pMap.FeatureSelection;

            //Enumerates through selected features, checking for ford-compatible transportation subtypes
            IEnumFeature pEnumFeat = (IEnumFeature)pMap.FeatureSelection;
            IFields fields;
            pEnumFeat.Reset();
            IEnumFeatureSetup enumFeatSetup = (IEnumFeatureSetup)pEnumFeat;
            enumFeatSetup.AllFields = true;
            {
                IFeature pfeat = pEnumFeat.Next();
                //Starts operation for undo/redo stack
                editor.StartOperation();
                //Loops over selected features and updates CTUU
                while (pfeat != null)
                {
                    fields = pfeat.Fields;
                    int idIndex = fields.FindField("ObjectID");
                    int ctuuIndex = fields.FindField("ZI026_CTUU");
                    int fcIndex = fields.FindField("FCSubtype");
                    int wd1Index = fields.FindField("zi016_wd1");
                    int fcsub = 0;
                    string searchValue = pfeat.get_Value(idIndex).ToString();
                    if (fcIndex != -1)
                    {
                        string fcsubstring = pfeat.get_Value(fcIndex).ToString();
                        fcsub = Convert.ToInt32(fcsubstring);
                    }
                    IObjectClass transfcobj = pfeat.Class;
                    IFeatureClass transfc = (IFeatureClass)transfcobj;
                    //FCSubtypes for transportation:
                    //RAILWAY_C - 100143
                    //RAILWAY_SIDETRACK - 100144
                    //CART_TRACK_C - 100150
                    //ROAD_C - 100152
                    //TRAIL_C - 100156
                    if (searchValue != "" && (fcsub == 100150 | fcsub == 100152 | fcsub == 100156))
                    {

                        //Updates roads, cart tracks, and trails to LOC = On Waterbody Bottom. Roads are updated RLE = Not Applicable, cart tracks and trails to RLE = Level
                        pfeat.set_Value(transfc.FindField("LOC"), 17);
                        if (fcsub == 100152)
                        {
                            pfeat.set_Value(transfc.FindField("RLE"), 998);
                        }
                        else if (fcsub == 100150 | fcsub == 100156)
                        {
                            pfeat.set_Value(transfc.FindField("RLE"), 2);
                        }

                        //Records shape of transportation and applies to new ford feature
                        IGeometry bridgeshape = pfeat.Shape;
                        IFeature newbridge = transfc.CreateFeature();
                        newbridge.Shape = bridgeshape;

                        //Sets F_CODE and FCSubtype of ford
                        newbridge.set_Value(transfc.FindField("F_CODE"), "BH070");
                        newbridge.set_Value(transfc.FindField("FCSubtype"), 100302);

                        //Maps all ford values to defaults
                        IRowSubtypes rowSubtypes = (IRowSubtypes)newbridge;
                        rowSubtypes.InitDefaultValues();

                        //Gets ZI026_CTUU of selected transportation feature and applies it to new bridge feature
                        string transctuustr = pfeat.get_Value(ctuuIndex).ToString();
                        int transctuu = Convert.ToInt32(transctuustr);
                        newbridge.set_Value(transfc.FindField("ZI026_CTUU"), transctuu);

                        //Sets TRS road types (road, cart track)
                        if (fcsub == 100150 | fcsub == 100152)
                        {
                            newbridge.set_Value(transfc.FindField("TRS"), 13);
                        }
                        //Sets TRS pedestrian types (trails)
                        else if (fcsub == 100156)
                        {
                            newbridge.set_Value(transfc.FindField("TRS"), 9);
                        }

                        //Sets default ford values
                        newbridge.set_Value(transfc.FindField("ZI016_ROC"), 1);
                        newbridge.set_Value(transfc.FindField("PCF"), 2);

                        pfeat.Store();
                        newbridge.Store();
                    }
                    pfeat = pEnumFeat.Next();
                }
                //Ends operation for undo/redo stack
                editor.StopOperation("Create ford(s)");
            }
            //Refreshes extent
            activeView.Refresh();
        }

        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
