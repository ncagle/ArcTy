﻿using System;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Editor;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geometry;

namespace BridgeTunnelFord_Builder_Prime
{
    public class Bridge : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public Bridge()
        {
        }

        protected override void OnClick()
        {
            IApplication m_application = ArcMap.Application;
            UID editorUid = new UID();
            editorUid.Value = "esriEditor.Editor";
            IMxDocument pMxdoc = (IMxDocument)ArcMap.Application.Document;
            IEditor3 editor = m_application.FindExtensionByCLSID(editorUid) as IEditor3;
            IWorkspace workspace = null;

            //Stops program unless an editing session is active; sets workspace to editing session otherwise
            if (editor.EditState == esriEditState.esriStateEditing)
            {
                workspace = editor.EditWorkspace;
            }
            else
            {
                MessageBox.Show("Editing session required");
                return;
            }

            IFeatureWorkspace workspacef = workspace as IFeatureWorkspace;
            //IFeatureClass transfc = workspacef.OpenFeatureClass("transportationgroundcrv");

            IActiveView activeView = ArcMap.Document.ActiveView;
            IMap pMap = activeView.FocusMap;
            ISelection selection = pMap.FeatureSelection;

            //Enumerates through selected features, checking for bridge-compatible transportation subtypes
            IEnumFeature pEnumFeat = (IEnumFeature)pMap.FeatureSelection;
            IFields fields;
            pEnumFeat.Reset();
            IEnumFeatureSetup enumFeatSetup = (IEnumFeatureSetup)pEnumFeat;
            enumFeatSetup.AllFields = true;
            {
                IFeature pfeat = pEnumFeat.Next();
                //Starts operation for undo/redo stack
                editor.StartOperation();
                //Loops over selected features and updates CTUU
                while (pfeat != null)
                {
                    fields = pfeat.Fields;
                    int idIndex = fields.FindField("ObjectID");
                    int ctuuIndex = fields.FindField("ZI026_CTUU");
                    int fcIndex = fields.FindField("FCSubtype");
                    int wd1Index = fields.FindField("zi016_wd1");
                    int fcsub = 0;
                    string searchValue = pfeat.get_Value(idIndex).ToString();
                    if (fcIndex != -1)
                    {
                        string fcsubstring = pfeat.get_Value(fcIndex).ToString();
                        fcsub = Convert.ToInt32(fcsubstring);
                    }
                    IObjectClass transfcobj = pfeat.Class;
                    IFeatureClass transfc = (IFeatureClass)transfcobj;
                    //FCSubtypes valid for bridges:
                    //RAILWAY_C - 100143
                    //RAILWAY_SIDETRACK - 100144
                    //CART_TRACK_C - 100150
                    //ROAD_C - 100152
                    //TRAIL_C - 100156
                    if (searchValue != "" && (fcsub == 100143 | fcsub == 100144 | fcsub == 100150 | fcsub == 100152 | fcsub == 100156))
                    {

                        //Updates selected transportation to SBB = True and RLE = Raised
                        pfeat.set_Value(transfc.FindField("SBB"), 1001);
                        pfeat.set_Value(transfc.FindField("RLE"), 1);

                        //Gets ZI016_WD1 of selected transportation feature
                        string widstr = pfeat.get_Value(wd1Index).ToString();
                        double wid = Convert.ToDouble(widstr);

                        //Records shape of transportation and applies to new bridge feature
                        IGeometry bridgeshape = pfeat.Shape;
                        IFeature newbridge = transfc.CreateFeature();
                        newbridge.Shape = bridgeshape;

                        //Sets F_CODE and FCSubtype of Bridge
                        newbridge.set_Value(transfc.FindField("F_CODE"), "AQ040");
                        newbridge.set_Value(transfc.FindField("FCSubtype"), 100161);

                        //Maps all bridge values to defaults
                        IRowSubtypes rowSubtypes = (IRowSubtypes)newbridge;
                        rowSubtypes.InitDefaultValues();

                        //Gets ZI026_CTUU of selected transportation feature and applies it to new bridge feature
                        string transctuustr = pfeat.get_Value(ctuuIndex).ToString();
                        int transctuu = Convert.ToInt32(transctuustr);
                        newbridge.set_Value(transfc.FindField("ZI026_CTUU"), transctuu);

                        //Sets TRS railway types (railway, railway sidetrack)
                        if (fcsub == 100143 | fcsub == 100144)
                        {
                            newbridge.set_Value(transfc.FindField("TRS"), 12);
                        }

                        //Sets TRS road types (road, cart track)
                        else if (fcsub == 100150 | fcsub == 100152)
                        {
                            newbridge.set_Value(transfc.FindField("TRS"), 13);
                        }
                        //Sets TRS pedestrian types (trails)
                        else if (fcsub == 100156)
                        {
                            newbridge.set_Value(transfc.FindField("TRS"), 9);
                        }

                        //If ZI016_WD1 is positive, sets width attribute of bridges supporting roads to WID + 2
                        if (fcsub == 100152 && wid > 0)
                        {
                            newbridge.set_Value(transfc.FindField("WID"), (wid + 2));
                        }

                        //Sets WID of bridges supporting cart tracks, trails, railroads, and railroad sidetracks to 5
                        if (fcsub == 100143 | fcsub == 100144 | fcsub == 100150 | fcsub == 100156)
                        {
                            newbridge.set_Value(transfc.FindField("WID"), 5);
                        }


                        //Finds AOO
                        //Code is functional but was determined not to be required
                        /*
                        IPolyline bridgepoly = (IPolyline) pfeat.Shape;
                        IPoint toPoint = bridgepoly.ToPoint;
                        IPoint fromPoint = bridgepoly.FromPoint;
                        ILine line = new Line();
                        line.FromPoint = fromPoint;
                        line.ToPoint = toPoint;
                        double normAngle = (180 * line.Angle) / Math.PI;
                        int aoo = Convert.ToInt32(normAngle);
                        aoo = ((aoo * -1) + 90) % 360;
                        if (aoo < 0)
                        {
                            aoo += 360;
                        }
                        newbridge.set_Value(transfc.FindField("AOO"), aoo);
                        */

                        //Sets default slab bridge values
                        newbridge.set_Value(transfc.FindField("BOT"), 17);
                        newbridge.set_Value(transfc.FindField("BSC"), 15);
                        newbridge.set_Value(transfc.FindField("PCF"), 2);
                        newbridge.set_Value(transfc.FindField("RFD"), 1000);

                        pfeat.Store();
                        newbridge.Store();
                    }
                    pfeat = pEnumFeat.Next();
                }
                //Ends operation for undo/redo stack
                editor.StopOperation("Create slab bridge(s)");
            }
            //Refreshes extent
            activeView.Refresh();
        }

        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}

